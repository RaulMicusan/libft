/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_power.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/12/13 13:55:55 by charangu          #+#    #+#             */
/*   Updated: 2017/12/13 15:52:09 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int		ft_power(int number, int power)
{
	if (power == 0)
		return (1);
	else if (power < 0)
		return (0);
	return (number * ft_power(number, power - 1));
}
