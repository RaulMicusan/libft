/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrev.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/12/13 13:49:26 by charangu          #+#    #+#             */
/*   Updated: 2017/12/13 15:49:30 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrev(char *str)
{
	char	temp_char;
	int		length;
	int		n;

	n = 0;
	length = 0;
	while (str[length])
		length++;
	while (n < length / 2)
	{
		temp_char = str[n];
		str[n] = str[length - n - 1];
		str[length - n - 1] = temp_char;
		n++;
	}
	return (str);
}
