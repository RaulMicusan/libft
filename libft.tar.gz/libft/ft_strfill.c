/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strfill.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: charangu <charangu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/12/07 18:53:13 by charangu          #+#    #+#             */
/*   Updated: 2017/12/07 18:53:23 by charangu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_strfill(char **tab, const char *s, char c)
{
	while (*s)
	{
		if (*s != c)
			*tab++ = ft_strqdupc(&s, c);
		s++;
	}
	*tab = NULL;
}
