/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mraul-mi <mraul-mi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/15 19:12:25 by mraul-mi          #+#    #+#             */
/*   Updated: 2018/01/17 17:20:49 by mraul-mi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memcpy(void *dst, const void *src, size_t n)
{
	char		*dest;
	const char	*from;

	dest = dst;
	from = src;
	while (n > 0)
	{
		*dest = *from;
		dest++;
		from++;
		n--;
	}
	return (dst);
}
